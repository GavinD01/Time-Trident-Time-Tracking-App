package com.example.timetridentgroupproject

import Models.Project
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText

import android.widget.Toast
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.ui.NavigationUI.setupWithNavController
import com.example.timetridentgroupproject.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.FirebaseApp
import com.google.firebase.storage.FirebaseStorage

class MainActivity : AppCompatActivity(), OnProjectClickListener, OnTaskClickListener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var storage: FirebaseStorage

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        FirebaseApp.initializeApp(this)
        storage = FirebaseStorage.getInstance()
        navController=Navigation.findNavController(this,R.id.activity_main_nav_host_fragment)
        setupWithNavController(binding.bottomNavigationView,navController)


    }
    override fun onProjectClicked(projectName: String) {
        // Create an instance of the fragment you want to navigate to
        val fragment = ActFragment()

        // Pass the project name to the fragment using a bundle
        val args = Bundle()
        args.putString("projectName", projectName)
        Log.d("Main", "$projectName")
        fragment.arguments = args

        // Replace the current fragment with the new fragment

        navController.navigate(R.id.action_homeFragment_to_actFragment, args)
    }

    override fun onTaskClicked(taskName: String) {

        val fragment2 = ViewTaskFragment()

        val args2 = Bundle()
        args2.putString("taskName", taskName)
        fragment2.arguments = args2
        navController.navigate(R.id.action_actFragment_to_viewTaskFragment, args2)

    }


}