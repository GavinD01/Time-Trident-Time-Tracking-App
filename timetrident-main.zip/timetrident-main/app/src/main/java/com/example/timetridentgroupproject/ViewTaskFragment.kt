package com.example.timetridentgroupproject

import Models.Project
import Models.Task
import android.R
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.timetridentgroupproject.databinding.FragmentViewTaskBinding
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.roundToInt


private val timeList = mutableListOf<Double>()
private val list = mutableListOf<Double>()
class ViewTaskFragment : Fragment() {
    private var _binding: FragmentViewTaskBinding? = null
    private val binding get() = _binding!!
    private val uid = FirebaseAuth.getInstance().currentUser?.uid
    //graph variables
    private lateinit var chart: BarChart

    //Timer variables
    private var timerStarted = false
    private lateinit var serviceIntent: Intent
    private var time = 0.0
    private var valueOfTime = 0.0
    private var totalDuration: Double = 0.0


    private val updateTimeReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent != null && intent.action == TimeService.TIMER_UPDATED) {
                time = intent.getDoubleExtra(TimeService.TIME_EXTRA, 0.0)
                binding.timeTV.text = getTimeStringFromDouble(time)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentViewTaskBinding.inflate(inflater, container, false)
        val view = binding.root

        binding.startStopButton.setOnClickListener { startStopTimer() }
        binding.resetButton.setOnClickListener { resetTimer() }
        binding.btnSafe.setOnClickListener { saveTime() }

        serviceIntent = Intent(requireContext(), TimeService::class.java)
        requireContext().registerReceiver(updateTimeReceiver, IntentFilter(TimeService.TIMER_UPDATED))

        val dateFormat = SimpleDateFormat("yyyy-MM-dd")
        val taskName = arguments?.getString("taskName")
        val prLst = Project.getProjects()
        val project = prLst.find { it._name == Project.currentProject }

        val tsList = project?.GetList()
        val task = tsList?.find{it._name == taskName}!!

        binding.tvTaskName.text = taskName
        binding.tvStatus.text = task?.GetStatus()
        binding.tvDescription.text = task.GetDesc()
        binding.tvDueDate.text = dateFormat.format(task._dueDate)
        binding.tvMotivation.text = "Almost there! Let's get moving to your minimum goal of ${task._minTime}"

        chart = binding.chart

        //val values = listOf(6000.5, 140.75, 300.25, 50.0, 160.5) // Example list of time values
        //Conor - getting list of time records
        val values = task.GetList()
        Log.e("Getting log data from task", "${values.toString()}")
        val labels = mutableListOf<String>()

        for (i in values){
            labels.add(i.toString())
        }

        setupBarChart()
        //initially adds to the graph
        //addData(values, labels)
        val formattedTimeList = values.map { formatTime(it) }
        val adapter = ArrayAdapter(requireContext(), R.layout.simple_list_item_1, formattedTimeList)
        binding.ListTime.adapter = adapter


        for (i in values){

            totalDuration += i
            task.SetTotal(totalDuration)
        }

        binding.tvDuration.text = formatTime(task.GetTotal())
        val formattedList = sumWithPreviousIndexes(values)
        updateGraphData(formattedList, labels)
        //10, 20, 11, 15. 10
        //10 [0], 30 [0 + 1], 41 [0 + 1 + 2]

        //60
        //updateGraphData()

        //checking if the user has reached their min or max time
        if (task._minTime.equals(formatTime(task.GetTotal()))){
            showAlertDialog()
            binding.tvMotivation.text = "You have surpassed your minimum time"
        }
        else if(task._maxTime.equals(formatTime(task.GetTotal()))){
            showAlertDialog()
            binding.tvMotivation.text = "You have surpassed your maximum time"
        }


        return view
    }

    override fun onResume() {
        super.onResume()
        if (timerStarted) {
            binding.startStopButton.text = "Stop"
        } else {
            binding.startStopButton.text = "Start"
        }
    }

    override fun onPause() {
        super.onPause()
        requireContext().unregisterReceiver(updateTimeReceiver)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun resetTimer() {
        stopTimer()
        time = 0.0
        binding.timeTV.text = "00:00:00"
    }

    private fun startStopTimer() {
        if (timerStarted)
            stopTimer()
        else
            startTimer()
    }

    private fun startTimer() {
        serviceIntent.putExtra(TimeService.TIME_EXTRA, time)
        requireContext().startService(serviceIntent)
        binding.startStopButton.text = "Stop"
        timerStarted = true
        binding.tvStatus.text = "In-Progress"
    }

    private fun stopTimer() {
        requireContext().stopService(serviceIntent)
        binding.startStopButton.text = "Start"
        timerStarted = false
        binding.tvStatus.text = "Complete"
    }

    private fun getTimeStringFromDouble(time: Double): String {
        val resultInt = time.roundToInt()
        val hours = resultInt % 86400 / 3600
        val minutes = resultInt % 86400 % 3600 / 60
        val seconds = resultInt % 86400 % 3600 % 60

        return makeTimeString(hours, minutes, seconds)
    }

    private fun saveTime() {
        valueOfTime = time
        /*val hours = valueOfTime.toInt() / 3600
        val minutes = valueOfTime.toInt() % 3600 / 60
        val seconds = valueOfTime.toInt() % 60*/

        val taskName = arguments?.getString("taskName")
        val prLst = Project.getProjects()
        val project = prLst.find { it._name == Project.currentProject }

        val tsList = project?.GetList()
        val task = tsList?.find{it._name == taskName}!!

        //timeList.add(valueOfTime)
        addDoubleToTimelogs(valueOfTime, project._id, task._id)
        //adding to task here
        task.addToList(valueOfTime)
        var lstoftime = task.GetList()
        val formattedTimeList = lstoftime.map { formatTime(it) }
        val adapter = ArrayAdapter(requireContext(), R.layout.simple_list_item_1, formattedTimeList)
        binding.ListTime.adapter = adapter

        for (i in lstoftime){

            totalDuration += i
            task.SetTotal(totalDuration)
        }

        val labels = mutableListOf<String>()
        val dateFormat = SimpleDateFormat("yyyy-MM-dd")

        for (i in lstoftime){
            labels.add(dateFormat.format(Calendar.getInstance().time))
        }

        binding.tvDuration.text = formatTime(task.GetTotal())
        totalDuration = 0.0

        /*list.add(task.GetTotal())
        updateGraphData(list, labels)*/

        val formattedList = sumWithPreviousIndexes(lstoftime)
        updateGraphData(formattedList, labels)

        

        //checking if the user has reached their min or max time
        if (task._minTime.equals(formatTime(task.GetTotal()))){
            showAlertDialog()
        }
        else if(task._maxTime.equals(formatTime(task.GetTotal()))){
            showAlertDialog()
        }

    }

    private fun makeTimeString(hour: Int, min: Int, sec: Int): String =
        String.format("%02d:%02d:%02d", hour, min, sec)

    private fun formatTime(time: Double): String {
        val resultInt = time.roundToInt()
        val hours = resultInt % 86400 / 3600
        val minutes = resultInt % 86400 % 3600 / 60
        val seconds = resultInt % 86400 % 3600 % 60

        val formattedHours = String.format("%02d", hours)
        val formattedMinutes = String.format("%02d", minutes)
        val formattedSeconds = String.format("%02d", seconds)

        return "$formattedHours h $formattedMinutes m $formattedSeconds s"
    }

    //For the graph
    private fun setupBarChart() {
        chart.apply {
            setDrawBorders(true)
            setBackgroundColor(Color.DKGRAY)
            description.isEnabled = false
            setTouchEnabled(true)
            setScaleEnabled(true)
            setPinchZoom(true)
            axisLeft.setDrawGridLines(false)
            axisRight.setDrawGridLines(false)
            xAxis.setDrawGridLines(false)
            legend.isEnabled = false
        }

        // Position the x-axis labels at the bottom
        val xAxis = chart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM

        // Position the y-axis labels only on the left side
        val leftAxis = chart.axisLeft
        leftAxis.isEnabled = false
        //leftAxis.axisDependency = LEFT

        val rightAxis = chart.axisRight
        rightAxis.isEnabled = false
    }

    private fun addData(values: List<Double>, labels: List<String>) {
        val entries = ArrayList<BarEntry>()

        for (i in values.indices) {
            entries.add(BarEntry(i.toFloat(), values[i].toFloat()))
        }

        val dataSet = BarDataSet(entries, "Bar Data Set")
        dataSet.color = R.color.holo_purple

        val barDataSets = ArrayList<IBarDataSet>()
        barDataSets.add(dataSet)

        val barData = BarData(barDataSets)

        chart.data = barData

        // Display values on the bar graphs
        val valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {

                val resultInt = value.roundToInt()
                val hours = resultInt % 86400 / 3600
                val minutes = resultInt % 86400 % 3600 / 60
                val seconds = resultInt % 86400 % 3600 % 60

                val formattedHours = String.format("%02d", hours)
                val formattedMinutes = String.format("%02d", minutes)
                val formattedSeconds = String.format("%02d", seconds)

                if (formattedHours.equals("00")){
                    return "$formattedMinutes m $formattedSeconds s"
                }

                else if (formattedHours.equals("00") && formattedMinutes.equals("00")){
                    return "$formattedSeconds s"
                }

                else{
                    return "$formattedHours h $formattedMinutes m $formattedSeconds s"
                }

                /*val hours = (value % 86400 / 3600).toInt()
                val minutes = (value % 86400 % 3600 / 60).toInt()
                val seconds = (value % 86400 % 3600 % 60).toInt()
                return String.format(Locale.getDefault(), "%d:%02d:%02d", hours, minutes, seconds)*/
            }
        }

        dataSet.valueFormatter = valueFormatter
        dataSet.valueTextColor = R.color.holo_purple
        dataSet.valueTextSize = 12f

        val xAxis = chart.xAxis
        xAxis.valueFormatter = LabelFormatter(labels)

        val leftAxis = chart.axisLeft
        leftAxis.valueFormatter = TimeValueFormatter()

        chart.invalidate()

    }

    // Custom label formatter for x-axis
    private inner class LabelFormatter(private val labels: List<String>) : ValueFormatter() {
        override fun getFormattedValue(value: Float): String {
            val index = value.toInt()
            return if (index >= 0 && index < labels.size) {
                labels[index]
            } else {
                ""
            }
        }
    }

    // Custom value formatter for y-axis (left)
    private inner class TimeValueFormatter : ValueFormatter() {
        override fun getFormattedValue(value: Float): String {
            val totalSeconds = value.toInt()

            val hours = totalSeconds % 86400 / 3600
            val minutes = totalSeconds % 86400 % 3600 / 60
            val seconds = totalSeconds % 86400 % 3600 % 60

            return String.format("%02d:%02d:%02d", hours, minutes, seconds)
        }
    }

    //update the graph
    //update the graph
    private fun updateGraphData(values: List<Double>, labels: List<String>) {
        val entries = ArrayList<BarEntry>()

        for (i in values.indices) {
            entries.add(BarEntry(i.toFloat(), values[i].toFloat()))
        }

        val dataSet = BarDataSet(entries, "Bar Data Set")
        dataSet.setColors(ContextCompat.getColor(requireContext(), R.color.holo_purple))

        val barDataSets = ArrayList<IBarDataSet>()
        barDataSets.add(dataSet)

        val barData = BarData(barDataSets)

        chart.data = barData

        // Display values on the bar graphs
        val valueFormatter = object : ValueFormatter() {
            override fun getFormattedValue(value: Float): String {
                val resultInt = value.roundToInt()
                val hours = resultInt % 86400 / 3600
                val minutes = resultInt % 86400 % 3600 / 60
                val seconds = resultInt % 86400 % 3600 % 60

                val formattedHours = String.format("%02d", hours)
                val formattedMinutes = String.format("%02d", minutes)
                val formattedSeconds = String.format("%02d", seconds)

                if (formattedHours.equals("00")) {
                    return "$formattedMinutes m $formattedSeconds s"
                } else if (formattedHours.equals("00") && formattedMinutes.equals("00")) {
                    return "$formattedSeconds s"
                } else {
                    return "$formattedHours h $formattedMinutes m $formattedSeconds s"
                }
            }
        }

        dataSet.valueFormatter = valueFormatter
        dataSet.valueTextColor = Color.BLACK
        dataSet.valueTextSize = 12f

        val xAxis = chart.xAxis
        xAxis.valueFormatter = LabelFormatter(labels)

        val leftAxis = chart.axisLeft
        leftAxis.valueFormatter = TimeValueFormatter()

        // Refresh the chart
        chart.invalidate()
    }

    private fun showAlertDialog() {
        val taskName = arguments?.getString("taskName")
        val prLst = Project.getProjects()
        val project = prLst.find { it._name == Project.currentProject }
        val tsList = project?.GetList()
        val task = tsList?.find{it._name == taskName}!!
        val alertDialogBuilder = AlertDialog.Builder(requireContext())
        alertDialogBuilder.setTitle("Time Reached")
        if (task._minTime.equals(formatTime(task.GetTotal()))){
            alertDialogBuilder.setMessage("Congratulations! You have reached your minimum set time.")
        }
        else if(task._maxTime.equals(formatTime(task.GetTotal()))){
            alertDialogBuilder.setMessage("Congratulations! You have reached your minimum set time.")
        }

        // Set a positive button and its click listener
        alertDialogBuilder.setPositiveButton("OK") { dialog, which ->
            // Handle the positive button click, if needed
            dialog.dismiss()  // Dismiss the dialog
        }

        // Create and show the dialog
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }





    fun addDoubleToTimelogs(doubleValue: Double, projectID: String, taskID: String) {
        val firestore = FirebaseFirestore.getInstance()

        val userDocumentRef = firestore.collection("users").document(uid.toString())
        val projectsSubCollectionRef = userDocumentRef.collection("projects").document(projectID)
        val tasksSubCollectionRef = projectsSubCollectionRef.collection("tasks").document(taskID)
        val timeLogsSubCollectionRef = tasksSubCollectionRef.collection("timelogs")

        // Create a query to check if the document exists
        val query = timeLogsSubCollectionRef.limit(1)

        query.get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    // Document already exists, update the array
                    val existingDocumentSnapshot = querySnapshot.documents[0]
                    val existingDocumentRef = existingDocumentSnapshot.reference
                    existingDocumentRef.update("doublesArray", FieldValue.arrayUnion(doubleValue))
                        .addOnSuccessListener {
                            // Success
                        }
                        .addOnFailureListener { e ->
                            // Error occurred while updating the document
                        }
                } else {
                    // Document doesn't exist, create it with the array
                    val newTimeLogData = hashMapOf(
                        "doublesArray" to arrayListOf(doubleValue)
                    )
                    timeLogsSubCollectionRef.add(newTimeLogData)
                        .addOnSuccessListener {
                            // Success
                        }
                        .addOnFailureListener { e ->
                            // Error occurred while creating the document
                        }
                }
            }
            .addOnFailureListener { e ->
                // Error occurred while retrieving the document
            }
    }

    fun sumWithPreviousIndexes(list: List<Double>): List<Double> {
        val resultList = mutableListOf<Double>()

        for (i in 0 until list.size) {
            val sum = if (i == 0) {
                list[i]
            } else {
                list[i] + resultList[i - 1]
            }
            resultList.add(sum)
        }

        return resultList
    }


}
