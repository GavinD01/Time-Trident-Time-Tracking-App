package com.example.timetridentgroupproject

interface OnProjectClickListener {
    fun onProjectClicked(projectName: String)
}