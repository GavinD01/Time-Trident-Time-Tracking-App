package com.example.timetridentgroupproject

import Models.Project
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.timetridentgroupproject.databinding.FragmentActBinding
import com.example.timetridentgroupproject.databinding.FragmentViewTaskBinding
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.timetridentgroupproject.databinding.FragmentHomeBinding
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import kotlin.math.log


class ActFragment : Fragment(R.layout.fragment_act) {
    companion object {
        fun newInstance(): ActFragment {
            return ActFragment()
        }
    }


    private var _binding: FragmentActBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: TasksAdapter
    private val storage = Firebase.storage
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        _binding = FragmentActBinding.inflate(inflater, container, false)
        val view = binding.root

        val projectName = arguments?.getString("projectName")
        if (projectName != null) {
            Project.currentProject = projectName
        }
        Log.d("Act Fragment", "$projectName")

        val prLst = Project.getProjects()
        val project = prLst.find { it._name == Project.currentProject }

        val dateFormat = SimpleDateFormat("yyyy-MM-dd")

        if (project != null) {
            GlobalScope.launch(Dispatchers.Main) {
                val bitmapData = retrieveImageFromFirebaseStorage(project.GetImg())
                // Use the bitmapData as needed
                binding.ivProjectImg.setImageBitmap(bitmapData)
            }
            binding.tvPrName.text = project._name
            binding.tvClientName.text = project._clientName
            binding.tvDueDate.text = dateFormat.format(project._dueDate)
            Log.d("Description:", project._description)
            binding.tvDescription.text = project._description

            Log.d("Is task initialized", "${project.isTaskInitialized()}")
            if (project.isTaskInitialized()) {
                Log.d("After initialization", "${project?._name}")
                //Get tasks from project
                val taskList = project.GetList()
                adapter = TasksAdapter(taskList , activity as OnTaskClickListener)
                Log.d("ActFragment", "${taskList[0]._name}")
                binding.rvTasks.adapter = adapter
                binding.rvTasks.layoutManager = LinearLayoutManager(requireContext())

            }
        }


        binding.btnAddTasks.setOnClickListener{
            findNavController().navigate(R.id.action_actFragment_to_addProjectTaskFragment)
        }

        return view

    }

    private suspend fun retrieveImageFromFirebaseStorage(path : String): Bitmap? {
        // Create a reference to the image in Firebase Storage
        val storageRef = storage.reference
        val imageRef = storageRef.child(path) // Path and filename should match the image you uploaded

        // Download the image from Firebase Storage
        val MAX_SIZE_BYTES: Long = 1024 * 1024 // Maximum size of the image you expect to download
        return try {
            val imageData = imageRef.getBytes(MAX_SIZE_BYTES).await()
            BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
        } catch (exception: Exception) {
            // Handle any errors that occurred during image download
            null
        }
    }


}