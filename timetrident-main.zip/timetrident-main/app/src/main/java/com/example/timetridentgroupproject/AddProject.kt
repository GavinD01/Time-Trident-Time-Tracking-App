package com.example.timetridentgroupproject

import Models.Project
import Models.User
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentFactory
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.fragment.findNavController
import com.example.timetridentgroupproject.databinding.FragmentAddProjectBinding
import java.text.SimpleDateFormat
import java.util.*
import androidx.navigation.fragment.findNavController
import android.app.Activity
import android.app.Activity.RESULT_OK
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.net.Uri

import android.provider.MediaStore
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.signature.ObjectKey
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import java.io.ByteArrayOutputStream

import kotlin.math.log


class AddProject : Fragment(R.layout.fragment_add_project) {

    private  var pickedImage = false
    private val firestore = Firebase.firestore
    private lateinit var storage: FirebaseStorage
    private lateinit var imageView: ImageView
    private val uid = FirebaseAuth.getInstance().currentUser?.uid
    private var _binding: FragmentAddProjectBinding? = null
    private val binding get() = _binding!!
    private lateinit var navController: NavController
    private var image: Uri = Uri.EMPTY
    private val PICK_IMAGE_REQUEST = 1
    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val selectedImageUri = result.data?.data
            // Store the selected image URI in the object's property
            if (selectedImageUri != null) {
                image = selectedImageUri
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAddProjectBinding.inflate(inflater, container, false)

        val view = binding.root
        navController = findNavController()
        Log.d("AddProject", "onCreateView() called")
        storage = FirebaseStorage.getInstance()


        binding.imgButton.setOnClickListener{
            pickImage()


            Glide.with(this)
                .load(image)
                .signature(ObjectKey(System.currentTimeMillis()))
                .into(binding.imgButton)

        }

        binding.btnAddProject.setOnClickListener{

                //Getting all input fields
                Log.d("AddProject", "Button clicked")
                val name = binding.projectName.text.toString()
                val companyName = binding.companyName.text.toString()
                val description = binding.description.text.toString()
                val datePicker = binding.dtpDueDate

                //Getting selected date
                val day = datePicker.dayOfMonth
                val month = datePicker.month
                val year = datePicker.year
                val selectedDate = "$year-${month + 1}-$day"
                val format = SimpleDateFormat("yyyy-MM-dd")
                val date = format.parse(selectedDate)


                //Error handling
                if(pickedImage==false || name.isNullOrEmpty() || companyName.isNullOrEmpty() || description.isNullOrEmpty()){
                    Log.d("EmptyFields", "Empty Fields")
                    Toast.makeText(context, "Please ensure all fields are complete", Toast.LENGTH_SHORT).show()
                }
                //Verifying date is not in the past
                else if(date.before(Date())){
                    Log.d("DateIncorrect", "Date Before Today")
                    Toast.makeText(context, "Please set a date that is not in the past", Toast.LENGTH_SHORT).show()
                }
                else{

                    val imagePath = uploadImage()
                    val data = hashMapOf(
                        "name" to name,
                        "client" to companyName,
                        "duedate" to date,
                        "image" to imagePath,
                        "description" to description
                    )
                    /*--------------------------------------------------------------------------------------*/
                    /*This code will check whether a sub collection of projects has already been made, and add the project to the sub collection*/

                    val userDocumentRef = firestore.collection("users").document(uid.toString())
                    val projectsSubCollectionRef = userDocumentRef.collection("projects")

                    projectsSubCollectionRef.get()
                        .addOnSuccessListener { querySnapshot ->
                            if (querySnapshot.isEmpty) {
                                // Subcollection does not exist, create it and add the project document
                                projectsSubCollectionRef.add(data)
                                    .addOnSuccessListener { documentReference ->
                                        // Project document added successfully
                                        // You can perform any additional actions here
                                        val projectId = documentReference.id
                                        //Creating new project, and storing in list of projects

                                        val newProject = Project(projectId, name, companyName, date, imagePath ,description)
                                        Project.addProject(newProject)
                                    }
                                    .addOnFailureListener { e ->
                                        Log.e("Error adding document to non-existing (projects)",e.toString())
                                    }
                            } else {
                                // Sub collection exists, directly add the project document
                                projectsSubCollectionRef.add(data)
                                    .addOnSuccessListener { documentReference ->
                                        // Project document added successfully
                                        val projectId = documentReference.id
                                        //Creating new project, and storing in list of projects
                                        val newProject = Project(projectId, name, companyName, date, imagePath ,description)
                                        Project.addProject(newProject)
                                    }
                                    .addOnFailureListener { e ->
                                        Log.e("Error adding document to existing (projects)",e.toString())
                                    }
                            }
                        }
                        .addOnFailureListener { e ->
                            Log.e("Error adding document to (projects)",e.toString())
                        }
                    /*--------------------------------------------------------------------------------------*/

                    Toast.makeText(context, "Project added successfully", Toast.LENGTH_SHORT).show()
                    Log.d("AddProject", "Project Added")
                    navController.navigate(R.id.action_addProject_to_homeFragment)

            }
        }
        return view
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.type = "image/*"
        pickImageLauncher.launch(intent)
        pickedImage = true
    }

    private fun uploadImage() : String{

        imageView = binding.imgButton
        // Convert ImageView to Bitmap
        val drawable = imageView.drawable
        val bitmap = (drawable as BitmapDrawable).bitmap

        // Create a reference to the image in Firebase Storage
        val storageRef = storage.reference
        val imageName = generateRandomName()
        val imageRef = storageRef.child("images/$imageName.jpg") // Change the path and filename as per your requirements

        // Convert Bitmap to ByteArray
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()

        // Upload the image to Firebase Storage
        val uploadTask = imageRef.putBytes(data)
        uploadTask.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                // Image upload successful
                // You can perform additional operations here
            } else {
                // Image upload failed
                // Handle the error here
            }
        }

        return "images/$imageName.jpg"
    }

    private fun generateRandomName(): String {
        val timestamp = Date().time
        val uniqueId = UUID.randomUUID().toString()
        return "image_$timestamp$uniqueId"
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }



}