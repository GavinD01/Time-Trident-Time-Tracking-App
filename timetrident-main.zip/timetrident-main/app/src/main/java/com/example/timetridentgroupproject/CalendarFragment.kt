package com.example.timetridentgroupproject
import Models.Project
import Models.Task
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
//import android.widget.CalendarView
import androidx.fragment.app.Fragment
import com.applandeo.materialcalendarview.CalendarView
import java.util.*
import android.util.Log
import com.applandeo.materialcalendarview.EventDay


class CalendarFragment : Fragment() {

    private lateinit var calendarView: CalendarView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_calendar, container, false)

        calendarView = view.findViewById(R.id.calendar)
        //calendarView.setOnDateChangeListener(null) // Disable default date selection

        // Set the desired dates
        val highlightedDates = mutableListOf<Calendar>()
        val highlightedTaskDates = mutableListOf<Calendar>()

        if (Project.isInitialized())
        {
            for (project in Project.getProjects()) {
                //Log.d("Items in arrayList", "Due date " + project._dueDate)
                val thisDate = Calendar.getInstance()
                thisDate.time = project._dueDate
                highlightedDates.add(thisDate)


                if (project.isTaskInitialized())
                {
                    for (task in project.GetList()) {
                        //Log.d("Items in  task List", "Due date " + task._dueDate)
                        val thisDate = Calendar.getInstance()
                        thisDate.time = task._dueDate
                        highlightedTaskDates.add(thisDate)
                    }
                    // Highlight the desired dates
                    highlightTaskDates(highlightedTaskDates)
                }
            }
            // Highlight the desired dates
            highlightDates(highlightedDates)
        }
        return view
    }

    private fun highlightDates(datesToHighlight: List<Calendar>) {
        val eventsDay = datesToHighlight.map {EventDay(it, R.drawable.event_indicator)}
        calendarView.setEvents(eventsDay)
    }

    private fun highlightTaskDates(datesToHighlight: List<Calendar>) {
        val eventsDayTask = datesToHighlight.map {EventDay(it, R.drawable.task_indicator)}
        calendarView.setEvents(eventsDayTask)

        calendarView.setHighlightedDays(datesToHighlight)
    }
}

