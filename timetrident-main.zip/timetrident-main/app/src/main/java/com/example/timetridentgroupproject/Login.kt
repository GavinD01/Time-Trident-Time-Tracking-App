package com.example.timetridentgroupproject

import Models.Project
import Models.Task
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.util.*

class Login : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    /*public override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        if (currentUser != null) {

            val intent = Intent(this, MainActivity::class.java)
            // start your next activity
            startActivity(intent)
            finish()
        }
    }*/

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()

        //Getting inputs
        val txtEmail = findViewById<EditText>(R.id.email)
        val txtPassword = findViewById<EditText>(R.id.password)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvRegisterNow = findViewById<TextView>(R.id.tvRegisterNow)

        //Verifying authentication
        btnLogin.setOnClickListener {
            val email: String = txtEmail.text.toString();
            val password: String = txtPassword.text.toString();

            if (email == null || password == null){
                val toast = Toast.makeText(applicationContext, "Please enter all required fields.", Toast.LENGTH_LONG)
                toast.show();
            }

            else{
                auth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {

                            PopulateData{
                                // Sign in success, update UI with the signed-in user's information
                                Toast.makeText(applicationContext,"Login complete.",Toast.LENGTH_SHORT).show()
                                val intent = Intent(this, MainActivity::class.java)
                                // start your next activity
                                startActivity(intent)
                            }

                        } else {
                            Toast.makeText(baseContext,"Authentication failed.",Toast.LENGTH_SHORT,).show();
                        }
                    }
            }
        }



        tvRegisterNow.setOnClickListener{
            val intent = Intent(this, Register::class.java)
            // start your next activity
            startActivity(intent)
        }

    }

    private fun PopulateData(callback: () -> Unit){


        /*Query database for all projects, and fill array with projects*/
        val db = Firebase.firestore
        val uid = FirebaseAuth.getInstance().currentUser?.uid

        val userDocumentRef = db.collection("users").document(uid.toString())
        val projectsSubCollectionRef = userDocumentRef.collection("projects")

        projectsSubCollectionRef.get()
            .addOnSuccessListener { querySnapshot ->
                for (document in querySnapshot.documents) {
                    // Access each project document data
                    val projectId = document.id
                    val name = document.getString("name").toString()
                    val client = document.getString("client").toString()
                    val date = document.getTimestamp("duedate")
                    val image = document.getString("image").toString()
                    val description =   document.getString("description").toString()

                    Log.d("Retrieving Project", name)
                    val existingProjects = Project(projectId, name, client, date!!.toDate(), image, description)
                    Project.addProject(existingProjects)

                    val projectsDocumentRef = userDocumentRef.collection("projects").document(projectId)
                    val taskSubCollectionRef = projectsDocumentRef.collection("tasks")
                    taskSubCollectionRef.get()
                        .addOnSuccessListener { queryTaskSnapshot ->
                            for (taskDocument in queryTaskSnapshot.documents) {
                                val taskId = taskDocument.id
                                val taskName = taskDocument.getString("name").toString()
                                val taskDescription = taskDocument.getString("description").toString()
                                val minTime = taskDocument.getString("mintime").toString()
                                val maxTime = taskDocument.getString("maxtime").toString()
                                val taskDate = taskDocument.getTimestamp("duedate")

                                Log.d("Retrieving Task for $name", taskName)
                                val existingTasks = Task(taskId, taskName, taskDescription, minTime, maxTime, taskDate!!.toDate())
                                existingProjects.addToTaskList(existingTasks)

                                val taskDocumentRef = projectsDocumentRef.collection("tasks").document(taskId)
                                val timeLogsSubCollection = taskDocumentRef.collection("timelogs")

                                timeLogsSubCollection.get()
                                    .addOnSuccessListener { queryTimeLogSnapshot->
                                        for (timeLogDocument in queryTimeLogSnapshot.documents) {
                                            val doublesArray = timeLogDocument.get("doublesArray") as? List<Double>
                                            if (doublesArray != null) {
                                                for(x in doublesArray){
                                                    existingTasks.addToList(x)
                                                }
                                            }
                                        }
                                    }
                                    .addOnFailureListener { e ->
                                        // Error occurred while retrieving the documents
                                    }
                            }
                            callback()
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e("Retrieving Data", e.toString())
            }
    }


}