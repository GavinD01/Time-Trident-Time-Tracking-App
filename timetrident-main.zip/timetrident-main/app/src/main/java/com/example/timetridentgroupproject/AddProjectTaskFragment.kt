package com.example.timetridentgroupproject

import Models.Project
import Models.Task
import android.os.Bundle
import android.text.InputFilter
import android.text.Spanned
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.example.timetridentgroupproject.databinding.FragmentAddProjectTaskBinding

import com.google.android.material.textfield.TextInputEditText

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import org.w3c.dom.Document

import java.text.SimpleDateFormat
import java.util.*


class AddProjectTaskFragment : Fragment(R.layout.fragment_add_project_task) {

    private var _binding: FragmentAddProjectTaskBinding? = null
    private val binding get() = _binding!!
    private val uid = FirebaseAuth.getInstance().currentUser?.uid
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAddProjectTaskBinding.inflate(inflater, container, false)
        val view = binding.root

        //Need code to find the name of the project that is clicked on here:    NB!!!!!!!!!!!!!!!!!!!!

        binding.btnAddProjectTask.setOnClickListener{
            activity?.runOnUiThread {

                Log.d("AddProject", "Button clicked")

                //Getting values from input fields
                val name = binding.taskName.text.toString()
                val description = binding.description.text.toString()

                val minTime = binding.minimumTime.text.toString()
                val maxTime = binding.maximumTime.text.toString()

                val datePicker = binding.dtpDueDate

                //Getting selected date
                val day = datePicker.dayOfMonth
                val month = datePicker.month
                val year = datePicker.year
                val selectedDate = "$year-${month + 1}-$day"
                val format = SimpleDateFormat("yyyy-MM-dd")
                val date = format.parse(selectedDate)

                //Error checking
                if (name.isNullOrEmpty() || description.isNullOrEmpty() || minTime.isNullOrEmpty() || maxTime.isNullOrEmpty()) {
                    Log.d("EmptyFields", "Empty Fields")
                    Toast.makeText(context, "Please ensure all fields are complete", Toast.LENGTH_SHORT).show()
                }
                //Verifying date is not in past
                else if(date.before(Date())){
                    Log.d("DateIncorrect", "Date Before Today")
                    Toast.makeText(context, "Please set a date that is not in the past", Toast.LENGTH_SHORT).show()
                }
                else{
                    val minTimeFormatted = formatTime(minTime)
                    val maxTimeFormatted = formatTime(maxTime)

                    //Creating new task





                    //Finding the correct project and adding task to list
                    var project = (Project.getProjects()).find {it._name == Project.currentProject}
                    Log.d("Finding project", "${project?._name}")
                    if (project != null) {


                        uploadTask(name, description, minTimeFormatted, maxTimeFormatted, date, project) { taskId ->
                            // Handle the document ID in this callback
                            if (taskId.isNotEmpty()) {
                                // Document ID is available, use it as needed
                                val newTask = Task(taskId, name, description, minTimeFormatted, maxTimeFormatted, date)
                                project.addToTaskList(newTask)
                                Log.d("Finding project", (project.GetList())[0]._name)
                                println("Uploaded task with ID: $taskId")
                            } else {
                                // An error occurred or the document ID is empty
                                println("Failed to upload task")
                            }
                        }

                    } else {
                        println("Project not found")
                    }
                    Toast.makeText(context, "Task added successfully", Toast.LENGTH_SHORT).show()
                    Log.d("AddTask", "Task Added")

                    findNavController().navigate(R.id.action_addProjectTaskFragment_to_actFragment)
                }

            }
        }
        binding.minimumTime.setOnKeyListener { v, keyCode, event ->
            val editText = v as TextInputEditText
            val editableText = editText.text

            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DEL) {
                val selectionStart = editText.selectionStart
                val selectionEnd = editText.selectionEnd

                // Check if ":" is selected
                if (selectionStart == selectionEnd && selectionStart > 0 && editableText?.get(selectionStart - 1) == ':') {
                    // Do not delete the ":" character
                    return@setOnKeyListener true
                }
            }

            return@setOnKeyListener false

        }
        binding.minimumTime.filters = arrayOf(TimeInputFilter())

        binding.maximumTime.setOnKeyListener { v, keyCode, event ->
            val editText = v as TextInputEditText
            val editableText = editText.text

            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DEL) {
                val selectionStart = editText.selectionStart
                val selectionEnd = editText.selectionEnd

                // Check if ":" is selected
                if (selectionStart == selectionEnd && selectionStart > 0 && editableText?.get(selectionStart - 1) == ':') {
                    // Do not delete the ":" character
                    return@setOnKeyListener true
                }
            }

            return@setOnKeyListener false
        }
        binding.maximumTime.filters = arrayOf(TimeInputFilter())




        return view
    }
    class TimeInputFilter : InputFilter {

        override fun filter(
            source: CharSequence?,
            start: Int,
            end: Int,
            dest: Spanned?,
            dstart: Int,
            dend: Int
        ): CharSequence? {
            val updatedText = StringBuilder(dest).apply {
                delete(dstart, dend)
                insert(dstart, source, start, end)
            }.toString()

            // Check if the updated text is in the format HH:MM:SS
            if (!updatedText.matches(Regex("^\\d{0,2}:\\d{0,2}:\\d{0,2}$"))) {
                // Return empty string to prevent the input
                return ""
            }

            // Validate each part (HH, MM, SS)
            val parts = updatedText.split(":")
            val hours = parts.getOrElse(0) { "00" }
            val minutes = parts.getOrElse(1) { "00" }
            val seconds = parts.getOrElse(2) { "00" }

            if (hours.toIntOrNull() ?: 0 > 99 || minutes.toIntOrNull() ?: 0 > 59 || seconds.toIntOrNull() ?: 0 > 59) {
                // Return empty string to prevent the input
                return ""
            }

            // Return null to accept the input as is
            return null
        }
    }


// format for time for min and max
    private fun formatTime(time: String): String {
        val parts = time.split(":")
        val hours = parts.getOrElse(0) { "00" }.take(2).padStart(2, '0')
        val minutes = parts.getOrElse(1) { "00" }.take(2).padStart(2, '0')
        val seconds = parts.getOrElse(2) { "00" }.take(2).padStart(2, '0')
        return "$hours:$minutes:$seconds"
    }


    private fun uploadTask(name : String, description : String, minTime : String, maxTime : String, date : Date, project : Project, callback: (String) -> Unit){
        val db = Firebase.firestore
        var id = ""
        val taskData = hashMapOf(
            "name" to name,
            "description" to description,
            "mintime" to minTime,
            "maxtime" to maxTime,
            "duedate" to date
        )


        val userDocumentRef = db.collection("users").document(uid.toString())
        val projectsSubCollectionRef = userDocumentRef.collection("projects").document(project._id)
        val tasksSubCollectionRef = projectsSubCollectionRef.collection("tasks")

        tasksSubCollectionRef.add(taskData)
            .addOnSuccessListener { documentReference ->
                id = documentReference.id
                Log.d("Adding task to db", "DocumentSnapshot successfully written!")
                callback(id)
            }
            .addOnFailureListener { e ->
                Log.w("Adding task to db", "Error writing document", e)
                callback("") // Invoke the callback with an empty string if an error occurs
            }

    }


}