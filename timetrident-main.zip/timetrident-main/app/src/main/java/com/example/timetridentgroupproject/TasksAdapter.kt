package com.example.timetridentgroupproject

import Models.Task
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.timetridentgroupproject.databinding.ItemProjectsBinding
import com.example.timetridentgroupproject.databinding.ItemTasksBinding
import java.text.SimpleDateFormat
import kotlin.math.roundToInt

class TasksAdapter(var tasks: ArrayList<Task>,private val clickListener: OnTaskClickListener): RecyclerView.Adapter<TasksAdapter.TasksViewHolder>() {

    val dateFormat = SimpleDateFormat("yyyy-MM-dd")

    inner class TasksViewHolder(val itemBinding: ItemTasksBinding) : RecyclerView.ViewHolder(itemBinding.root){

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TasksViewHolder {
        return TasksViewHolder(ItemTasksBinding.inflate(LayoutInflater.from(parent.context),parent, false))
    }

    override fun getItemCount(): Int {
        return tasks.size
    }

    override fun onBindViewHolder(holder: TasksViewHolder, position: Int) {
        holder.itemBinding.apply{

            tvTsName.text = tasks[position].GetName()
            tvTsStatus.text = tasks[position].GetStatus()
            tvDuration.text = formatTime(tasks[position].GetTotal())
            tvDueDate.text = dateFormat.format(tasks[position]._dueDate)
            //ivTaskImg.setImageURI(tasks[position].GetImg()) --> Change this conor :)

        }

        holder.itemView.setOnClickListener {
            clickListener.onTaskClicked("${tasks[position].GetName()}")
        }

    }

    private fun formatTime(time: Double): String {
        val resultInt = time.roundToInt()
        val hours = resultInt % 86400 / 3600
        val minutes = resultInt % 86400 % 3600 / 60
        val seconds = resultInt % 86400 % 3600 % 60

        val formattedHours = String.format("%02d", hours)
        val formattedMinutes = String.format("%02d", minutes)
        val formattedSeconds = String.format("%02d", seconds)

        return "$formattedHours h $formattedMinutes m $formattedSeconds s"
    }


}