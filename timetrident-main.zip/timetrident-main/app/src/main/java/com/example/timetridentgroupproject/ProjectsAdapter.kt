package com.example.timetridentgroupproject

import Models.Project
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.timetridentgroupproject.databinding.ItemProjectsBinding

import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.ktx.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import kotlin.math.roundToInt

class ProjectsAdapter(var projects: ArrayList<Project>,private val clickListener: OnProjectClickListener) : RecyclerView.Adapter<ProjectsAdapter.ProjectsViewHolder>() {


    val dateFormat = SimpleDateFormat("yyyy-MM-dd")
    /*private lateinit var storage: FirebaseStorage*/
    private val storage = Firebase.storage

    inner class ProjectsViewHolder(val itemBinding: ItemProjectsBinding) : RecyclerView.ViewHolder(itemBinding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProjectsViewHolder {
        return ProjectsViewHolder(ItemProjectsBinding.inflate(LayoutInflater.from(parent.context),parent, false))
    }

    override fun getItemCount(): Int {
        return projects.size
    }

    override fun onBindViewHolder(holder: ProjectsViewHolder, position: Int) {
        holder.itemBinding.apply{
            tvPrName.text = projects[position].GetName()
            tvPrStatus.text = projects[position].GetStatus()


            GlobalScope.launch(Dispatchers.Main) {
                val bitmapData = retrieveImageFromFirebaseStorage(projects[position].GetImg())
                // Use the bitmapData as needed
                ivProjectImg.setImageBitmap(bitmapData)
            }

            
            tvDueDate.text = dateFormat.format(projects[position]._dueDate)

            var total = 0.0
            if(projects[position].isTaskInitialized())
            {
            val tasks = projects[position].GetList()



                for(task in tasks){
                    {
                        total += task.GetTotal()
                    }

                }
            }

            tvDuration.text = formatTime(total)

          
            Log.d("ProjectAdapter", tvPrName.text.toString())

            holder.itemView.setOnClickListener {
                clickListener.onProjectClicked("${projects[position].GetName()}")
            }
        }
    }

    private suspend fun retrieveImageFromFirebaseStorage(path : String): Bitmap? {
        // Create a reference to the image in Firebase Storage
        val storageRef = storage.reference
        val imageRef = storageRef.child(path) // Path and filename should match the image you uploaded

        // Download the image from Firebase Storage
        val MAX_SIZE_BYTES: Long = 1024 * 1024 // Maximum size of the image you expect to download
        return try {
            val imageData = imageRef.getBytes(MAX_SIZE_BYTES).await()
            BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
        } catch (exception: Exception) {
            // Handle any errors that occurred during image download
            null
        }
    }

    private fun formatTime(time: Double): String {
        val resultInt = time.roundToInt()
        val hours = resultInt % 86400 / 3600
        val minutes = resultInt % 86400 % 3600 / 60
        val seconds = resultInt % 86400 % 3600 % 60

        val formattedHours = String.format("%02d", hours)
        val formattedMinutes = String.format("%02d", minutes)
        val formattedSeconds = String.format("%02d", seconds)

        return "$formattedHours h $formattedMinutes m $formattedSeconds s"
    }

}