package com.example.timetridentgroupproject

interface OnTaskClickListener {

    fun onTaskClicked(taskName: String)

}