package Models

class Record (private val _duration: Double){

    //properties for a time record
    /*private var _duration: Double = 0.0*/

    /*//Getters and setters
    fun SetStartTime(sTime: Long?) {
        _startTime = sTime
    }

    fun GetStartTime(): Long? {
        return _startTime
    }

    fun SetEndTime(eTime: Long?) {
        _endTime = eTime
    }

    fun GetEndTime(): Long? {
        return _endTime
    }*/

    /*fun SetDuration(dur: Double) {
        _duration = dur
    }*/

    fun GetDuration(): Double {
        return _duration
    }

}