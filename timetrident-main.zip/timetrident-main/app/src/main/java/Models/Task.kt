package Models

import java.util.*


class Task(val _id : String, val _name: String, var _description: String, val _minTime: String, val _maxTime: String, val _dueDate: Date) {


    //properties for a user task

    private var _taskImage: String? = null
    private var _status: String? = null
    private var _totalTime: Double = 0.0
    private var _listOfRecords = mutableListOf<Double>()

    //Getters and setters

    /*fun AddToTotalTime(time: Double){

        _totalTime = _totalTime?.plus(time);

    }*/
    fun GetName(): String? {
        return _name
    }


    fun GetMin(): String? {

        return _minTime
    }



    fun GetMax(): String? {
        return _maxTime
    }


    fun GetDate(): Date? {
        return _dueDate
    }

    fun SetImg(img: String?) {
        _taskImage = img
    }

    fun GetImg(): String? {
        return _taskImage
    }

    fun SetStatus(status: String?) {
        _status = status
    }

    fun GetStatus(): String? {
        return _status
    }


    fun GetDesc(): String? {
        return _description
    }

    fun SetTotal(total: Double) {
        _totalTime = total
    }

    fun GetTotal(): Double {
        return _totalTime
    }

    fun addToList(record: Double) {

        _listOfRecords.add(record)
    }

    fun GetList(): List<Double> {
        return _listOfRecords
    }


}