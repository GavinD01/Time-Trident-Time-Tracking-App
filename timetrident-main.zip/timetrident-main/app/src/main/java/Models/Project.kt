package Models

import android.net.Uri
import java.util.*


class Project (val _id: String, val _name: String, var _clientName: String, val _dueDate: Date, var _prImage: String , var _description: String){

    //List of tasks for each project
    companion object{
        lateinit var currentProject: String
        private lateinit var _prLists: ArrayList<Project>
        private var isInitialized: Boolean = false
        fun addProject(project: Project) {
            if (!isInitialized) {
                _prLists = ArrayList()
                isInitialized = true
            }
            _prLists.add(project)
        }
        fun getProjects(): ArrayList<Project> {
            return _prLists
        }
        fun isInitialized(): Boolean {
            return isInitialized
        }

    }
    private var _totalTime: Long? = null
    private lateinit var _listOfTasks: ArrayList<Task>
    private var _status: String = "Incomplete"
    private var isTaskInitialized: Boolean = false

    //Managing task list
    fun isTaskInitialized(): Boolean {
        return isTaskInitialized
    }
    fun addToTaskList(task: Task){
        if (!isTaskInitialized) {
            _listOfTasks = ArrayList()
            isTaskInitialized = true
        }
        _listOfTasks.add(task)
    }
    fun GetList(): ArrayList<Task> {
        return _listOfTasks
    }
    fun GetName(): String? {
        return _name
    }

    fun GetCName(): String? {
        return _clientName
    }

    fun GetStatus(): String? {
        return _status
    }

    fun GetDesc(): String? {
        return _description
    }


    fun GetTotal(): Long? {
        return _totalTime
    }


    fun GetDate(): Date? {
        return _dueDate
    }


    fun GetImg(): String {
        return _prImage
    }


}