package Models

import com.example.timetridentgroupproject.AddProject

class User {

    //Properties


    private var _taskLists: List<Task>? = null

    //Getters and setters




    fun SetTList(lst: List<Task>?) {
        _taskLists = lst
    }

    fun GetTList(): List<Task>? {
        return _taskLists
    }

}